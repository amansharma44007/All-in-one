﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class GreatestAmongThree
    {
        internal static void Test()
        {
            int a, b, c;
            Console.Write("Enter the Value of A: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Enter the Value of B: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Enter the Value of C: ");
            c = int.Parse(Console.ReadLine());
            if(a ==b && b== c)
            {
                Console.WriteLine("All the Number are Same");
            }
            if(a==b && b != c)
            {
                if (b > c)
                {
                    Console.WriteLine($"A-{a} and B-{b} are greater than C-{c}");
                }
                else
                {
                    Console.WriteLine($"C-{c} is greater than A-{a} and B-{b}");
                }
            }
            if(b == c && b!= a){
                if(b > a)
                {
                    Console.WriteLine($"B-{b} and C-{c} are greater than A-{a}");
                }
                else
                {
                    Console.WriteLine($"A-{a} is greater than B-{b} and C-{c}");
                }
            }
            if(a==c && a != b)
            {
                if (b > a)
                {
                    Console.WriteLine($"B-{b} is are greater than A-{a} and C-{c}");
                }
                else
                {
                    Console.WriteLine($"A-{a} and C-{c} is greater than B-{b}");
                }
            }
            if(a!=b && b!=c && c != a)
            {
                if(a>b && a > c)
                {
                    Console.WriteLine($"A-{a} is greater than B-{b} and C-{c}");
                }
                if(b>a && b > c)
                {
                    Console.WriteLine($"B-{b} is greater than A-{a} and C-{c}");
                }
                if(c>a && c > b)
                {
                    Console.WriteLine($"C-{c} is greater than A-{a} and B-{b}");
                }
            }
        }
    }
}
