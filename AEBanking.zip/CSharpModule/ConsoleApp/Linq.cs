﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Linq
    {
        static List<string> cities=new List<string> { "Mumbai","Delhi","Pune","Ahemdabad"};
        public static void Test()
        {
            BasicQuery();
        }
        static void BasicQuery()
        {
            var query=from city in cities 
                      where city.StartsWith('M') 
                      select city;
            var q=from city in cities
                  where (city.StartsWith('P') || city.StartsWith('B')) && city.Length>2
                  select city;
            foreach (var item in query)
            {
                Console.Write($"{item}\t");
            }
            Console.WriteLine();
            foreach (var item in q)
            {
                Console.Write($"{item}\t");
            }
            Console.WriteLine();
            Console.WriteLine("order");
            var q1 = from city in cities
                     orderby city.Length descending, city[0] ascending
                     select new {
                         Length = city.Length,
                         Name = city,
                         firstLetter = city[0]
                     };
            foreach (var item in q1)
            {
                Console.Write($"{item.Name} {item.firstLetter} {item.Length}\t");

            }
            Console.WriteLine("-----------------------------");
            var query1 = cities.Select(city => city);
            foreach (var item in query1)
            {
                Console.Write($"{item}\t");
            }
            var query2 = cities.Where(city => city.StartsWith('P')).Select(c=>c);
            foreach (var item in query2)
            {
                Console.WriteLine(item);
            }
            var query3 = cities.Where(city => city.StartsWith('P') || city.StartsWith('M') && city.Length > 2);
            foreach (var item in query3)
            {
                Console.WriteLine(item);
            }
            var a1 = cities.Take(2);
            Console.WriteLine("==================");
            foreach (var item in a1)
            {
                Console.WriteLine(item);
            }
            var a2 = cities.Skip(2);
            Console.WriteLine("==================");
            foreach (var item in a2)
            {
                Console.WriteLine(item);
            }
            var number = Enumerable.Range(start: 101, count: 100);
            StringBuilder s = new StringBuilder();
            s.AppendLine($"Max {number.Max()}")
                .AppendLine($"Max {number.Min()}")
                .AppendLine($"Max {number.Average()}")
                .AppendLine($"Max {number.Count()}")
                .AppendLine($"Max {number.Sum()}");
            Console.WriteLine(s);

            var z = cities.First();
            var z1 = cities.Last();
            var z2 = cities.First(c => c.Length > 4);
            var z3 = cities.Last(c => c.Length > 4);
            Console.WriteLine("{0} {1} {2} {3}",z,z1,z2,z3);

            var z4 = cities.FirstOrDefault(c => c.Contains('z'));
            Console.WriteLine(z4);

        }
    }
}
