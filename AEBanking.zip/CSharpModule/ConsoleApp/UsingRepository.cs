﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class UsingRepository
    {
        internal static void Test()
        {
            new UsingRepository().Run();
        }
        IRepository<Customer, string> repository;
        public UsingRepository()
        {
            repository = new CustomerRepository();
        }
        public void Run()
        {
            string choice = "";
            do
            {
                BuildMenu();
                SwitchChoices();
            } while (choice != "9");
            void SwitchChoices()
            {
                switch (choice)
                {
                    case "1": GetAllCustomers(); break;
                    case "2": GetByFilter(); break;
                    case "3": GetById(); break;
                    case "4": InsertNewCustomer(); break;
                    case "5": UpdateCustomer(); break;
                    case "6": DeleteCustomer(); break;
                    case "9": break;
                    default:
                        Console.WriteLine("Wrong choice. Please choose between 1-6 or 9 only.");
                        Console.WriteLine("Press a key to try again.");
                        Console.ReadKey();
                        break;
                }
            }
            void BuildMenu()
            {
                Console.Clear();
                Console.WriteLine("*****************  Customer management ******************");
                Console.WriteLine("\t\t1. Show All Customers");
                Console.WriteLine("\t\t2. Get Customers By Filter");
                Console.WriteLine("\t\t3. Get Customers By Id");
                Console.WriteLine("\t\t4. Add new Customer");
                Console.WriteLine("\t\t5. Update Customer Data");
                Console.WriteLine("\t\t6. Remove Customer");
                Console.WriteLine("\n\t\t9. Quit");
                Console.Write("\nEnter Choice (1-7 OR 9 to exit): ");
                choice = Console.ReadLine();
            }
        }
        private void ClearScreenHelper()
        {
            Console.WriteLine("\n\n Press a key to go back to menu");
            Console.ReadKey();
        }
        private void GetAllCustomers() {
            Console.Clear();
            Console.WriteLine("************List of Customer**************");
            var items = repository.GetAll();
            items.ToList().ForEach(c => Console.WriteLine($"{c.CustomerID} {c.CompanyName} {c.ContactName} {c.Country} {c.City}")
            );
            ClearScreenHelper();
        }
        private void GetByFilter() {
            Console.Clear();
            Console.WriteLine("************List of Customer By Filter**************");
            Console.WriteLine("Please Enter The word to search in Customers: ");
            string p = Console.ReadLine();
            var items = repository.GetBy(p);
            items.ToList().ForEach(c => Console.WriteLine($"{c.CustomerID} {c.CompanyName} {c.ContactName} {c.Country} {c.City}")
            );
            ClearScreenHelper();
        }
        private void GetById() {
            Console.WriteLine("Enter the id that you want to search: ");
            var id = Console.ReadLine();
            var c = repository.GetById(id);
            if ( c!= null)
            {
                Console.WriteLine($"{c.CustomerID} {c.CompanyName} {c.ContactName} {c.Country} {c.City}");
            }
            else
            {
                Console.WriteLine("No data in database");
            }
            ClearScreenHelper();

        }
        private void InsertNewCustomer() {
            Console.WriteLine("*****************Insert****************");
            Customer c = new Customer();
            Console.Write("Enter the Customer Id: ");
            c.CustomerID=Console.ReadLine();
            Console.Write("Enter the Company Name: ");
            c.CompanyName = Console.ReadLine();
            Console.Write("Enter the Conatct Name: ");
            c.ContactName = Console.ReadLine();
            Console.Write("Enter the Countrey: ");
            c.Country = Console.ReadLine();
            Console.Write("Enter the City: ");
            c.City = Console.ReadLine();
            if(string.IsNullOrEmpty(c.CustomerID)||string.IsNullOrEmpty(c.ContactName)||string.IsNullOrEmpty(c.CompanyName)
                || string.IsNullOrEmpty(c.Country)|| string.IsNullOrEmpty(c.City))
            {
                Console.WriteLine("1 or more field is empty or null");
                return;
            }
            else
            {
                if(!(string.IsNullOrEmpty(c.CustomerID)) && c.CustomerID.Length <= 5)
                {
                    repository.upsert(c);
                }
                else
                {
                    Console.WriteLine("Customer Id should be equal to 5 or less than!!!");
                }
            }
            ClearScreenHelper();

        }
        private void UpdateCustomer() {
            Console.Clear();
            Console.WriteLine("********************Update**********************");
            Console.Write("Please Enter the Id: ");
            var c=Console.ReadLine();
            var c1 = repository.GetById(c);
            if(c1 is null)
            {
                Console.WriteLine("This Id is Not there in database");
            }
            else
            {
                Console.WriteLine("First the old value will be seen");
                Console.WriteLine("The current value of Company name "+c1.CompanyName);
                Console.Write("The Comapnay name that you want: ");
                string a = Console.ReadLine();
                c1.ContactName=string.IsNullOrEmpty(a)?c1.ContactName:a;

                Console.WriteLine("The current value of Country name " + c1.Country);
                Console.Write("The Country name that you want: ");
                string a1 = Console.ReadLine();
                c1.Country = string.IsNullOrEmpty(a1) ? c1.Country : a1;

                Console.WriteLine("The current value of Co name " + c1.ContactName);
                Console.Write("The Contact  name that you want: ");
                string a2 = Console.ReadLine();
                c1.ContactName = string.IsNullOrEmpty(a2) ? c1.Country : a2;

                Console.WriteLine("The current value of City name " + c1.City);
                Console.Write("The Country name that you want: ");
                string a3 = Console.ReadLine();
                c1.City = string.IsNullOrEmpty(a3) ? c1.Country : a3;

                repository.upsert(c1);
                ClearScreenHelper();

            }

        }
        private void DeleteCustomer() {
            Console.WriteLine("***********Delete**************");
            Console.Write("Please Enter the Id");
            var c = Console.ReadLine();
            var c1 = repository.GetById(c);
            if(c1 is null)
            {
                Console.WriteLine("No there is no Id here");
            }
            else
            {
                Console.WriteLine($"{c1.CustomerID} {c1.CompanyName} {c1.ContactName} {c1.Country} {c1.City}");
                Console.Write("Are you want to delete");
                var a = Console.ReadLine().ToLower();
                if (a == "y")
                {
                    repository.Delete(c);
                }
            }
        }
    }
}
