﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class SumOfNaturalNumbers
    {
        internal static void Test()
        {
            int n;
            Console.Write("Enter the Value of n: ");
            n=int.Parse(Console.ReadLine());
            Console.WriteLine("Answer"+" "+(n*(n + 1)/2));
        }
    }
}
