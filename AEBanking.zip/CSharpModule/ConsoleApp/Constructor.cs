﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Constructor
    {
        private int id;
        private string name;
        private string address;
        private double salary;
        public Constructor():this(0)
        {
            this.id=0;
            this.name = "<<NA>>";
            this.address = "<<NA>>";
            this.salary = 0.0;
            Console.WriteLine("0");
        }
        public Constructor(int id) : this(id, "<<NA>>")
        {
            this.id = id;
            this.name = "<<NA>>";
            this.address = "<<NA>>";
            this.salary = 0.0;
            Console.WriteLine("1");
        }
        public Constructor(int id,string name):this(id,name,"<<NA>>")
        {
            this.id = id;
            this.name = name;
            this.address = "<<NA>>";
            this.salary = 0.0;
            Console.WriteLine("1 2");
        }
        public Constructor(int id, string name,string address):this(id,name,address,0.0)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.salary = 0.0;
            Console.WriteLine("1 2 3");
        }
        public Constructor(int id, string name, string address,double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.salary = salary;
            Console.WriteLine("1 2 3 4");
        }
        public static void Test()
        {
            Constructor c1 = new Constructor();
            Constructor c2 = new Constructor(1);
            Constructor c3 = new Constructor(1, "Aman");
            Constructor c4 = new Constructor(1, "Aman", "dhdvhd");
            Constructor c5 = new Constructor(1, "ddjnd", "djdhd", 2.2);
        }
    }
    
}
