﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class BuiltInDelegate
    {
        internal static void  Test()
        {
            Action a1 = () => Console.WriteLine("Action Delegate Invoked");
            Action<int, int, int> a2 = (a, b, c) => Console.WriteLine($"{a + b + c}");
            a1.Invoke();
            a2(10, 20, 30);
            Func<string> a3 =()=>"hello";
            Func<int, int, int> a4 = (a, b) => a + b;
            Console.WriteLine(a3());
            Console.WriteLine(a4.Invoke(2,3));
            Predicate<string> p1=(word)=>word.Contains("a");
            bool a = p1.Invoke("Bengaluru");
            Console.WriteLine($"Bengaluru contains a ?{a}");
        }
    }
}
