﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class CustomerRepository : IRepository<Customer, string>
    {
        AEDBContext db;
        public CustomerRepository()
        {
            db=new AEDBContext();
        }
        public void Delete(string id)
        {
            var obj = db.Customers.AsNoTracking().FirstOrDefault(c => c.CustomerID == id);
            if(obj != null)
            {
                db.Customers.Remove(obj);
                db.SaveChanges();
            }
        }

        public IEnumerable<Customer> GetAll()
        {
            return db.Customers.AsNoTracking().ToList();
        }

        public IEnumerable<Customer> GetBy(string p)
        {
            var parameters = p.Trim().Split(' ');
            return db.Customers.AsNoTracking().AsEnumerable()
                .Where(cust => parameters.Any(
                    pa=>
                    cust.CompanyName.StartsWith(pa,StringComparison.OrdinalIgnoreCase)||
                    cust.ContactName.StartsWith(pa, StringComparison.OrdinalIgnoreCase)||
                    cust.CustomerID.StartsWith(pa, StringComparison.OrdinalIgnoreCase)||
                    cust.Country.StartsWith(pa, StringComparison.OrdinalIgnoreCase)||
                    cust.City.StartsWith(pa, StringComparison.OrdinalIgnoreCase))).ToList();
        }

        public Customer GetById(string id)
        {
            return db.Customers.AsNoTracking().FirstOrDefault(c => c.CustomerID == id);
        }

        public void upsert(Customer item)
        {
            var obj = db.Customers.AsNoTracking().FirstOrDefault(c => c.CustomerID == item.CustomerID);
            if (obj != null)
            {
                //db.Entry(item).State = EntityState.Modified;
                db.Update(item);
                db.SaveChanges();
            }
            else{
                db.Add(item);
                db.SaveChanges();
            }
        }
    }
}
