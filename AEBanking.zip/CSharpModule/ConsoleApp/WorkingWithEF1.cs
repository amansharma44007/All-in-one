﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class WorkingWithEF1
    {
        public static void Test()
        {
            AEDBContext db = new AEDBContext();
            /*var items = db.Customers.AsNoTracking().ToList();
            foreach (var item in items)
            {
                Console.WriteLine($"{item.CustomerID} {item.ContactName} {item.CompanyName} {item.Country} {item.City}");
            }
            items = db.Customers.AsNoTracking().Where(c => c.Country == "USA").Select(c => c).ToList();
            Console.WriteLine("****************************************");
            foreach (var item in items)
            {
                Console.WriteLine($"{item.CustomerID} {item.ContactName} {item.CompanyName} {item.Country} {item.City}");
            }
            Console.WriteLine("*********************************");
            items = db.Customers.AsNoTracking().Where(c => c.CompanyName.StartsWith("A")).Select(c => c).ToList();
            foreach (var item in items)
            {
                Console.WriteLine($"{item.CustomerID} {item.ContactName} {item.CompanyName} {item.Country} {item.City}");
            }*/
            Console.WriteLine("****************************");
            Console.WriteLine("Please Enter a key to insert");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Enter the all values to insert: ");
            Customer c = new Customer();
            Console.Write("CustomeId: ");
            c.CustomerID = Console.ReadLine();
            Console.Write("Company Name: ");
            c.CompanyName= Console.ReadLine();
            Console.Write("Country Name: ");
            c.Country=Console.ReadLine();
            Console.Write("City Name: ");
            c.City=Console.ReadLine();
            Console.Write("Contact Name: ");
            c.ContactName= Console.ReadLine();
            db.Customers.Add(c);
            db.SaveChanges();
            var item = db.Customers.AsNoTracking().FirstOrDefault(x => x.CustomerID == c.CustomerID);
            if (item != null)
            {
                Console.WriteLine("Inserted");
            }
            else
            {
                Console.WriteLine("Not Inserted");
            }
        }
        
    }
}
