﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ConsoleApp
{
    
    public  class AEDBContext:Microsoft.EntityFrameworkCore.DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                connectionString: @"server=(localdb)\MSSQLLocalDB;database=AEDB;integrated security=sspi"
        ).LogTo(Console.WriteLine);
        }
        public DbSet<Customer> Customers { get; set; }
    }
}
