﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    interface Head
    {
        void start();
        String name { get; }
    }
    interface Head1 : Head
    {
        void stop();

    }
    class InterfaceImplementation : Head1, Head
    {
        public string name { get => "hello world"; }

        public void start()
        {
            Console.WriteLine("Start");
        }

        public void stop()
        {
            Console.WriteLine("Stop");
        }
        void Head.start() => Console.WriteLine("hello world stark");
    }
    internal class Interface
    {
        public static void Test()
        {
            InterfaceImplementation i = new InterfaceImplementation();
            Console.WriteLine(i.name);
            i.start();
            i.stop();
            Head h1 = i;
            Console.WriteLine(h1.name);
            h1.start();
            Head1 h2 = i;
            Console.WriteLine(h1.name);
            h2.start();
            h2.stop();
        }
    }
}
