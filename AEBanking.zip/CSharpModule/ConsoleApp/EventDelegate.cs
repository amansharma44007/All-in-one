﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class CustomEventArgs:System.EventArgs {
        public int num { get; set; }
        public string message { get; set; }
    }
    public delegate void CustomDelegate(object sender, CustomEventArgs e);
    class Publisher
    {
        public CustomDelegate CustomEvents;
        public void RaiseNotification()
        {
            for (int i = 0; i < 10; i++)
            {
                if(i==5 || i == 6)
                {
                    CustomEventArgs e=new CustomEventArgs { num=i,message="Thersold reached"};
                    OnCustomEvent(e);
                }
            }
        }
        protected void OnCustomEvent(CustomEventArgs e) => CustomEvents?.Invoke(this, e);
    }
    class Subscriber
    {
        public void HandleNotifiy(object sender, CustomEventArgs e)=>
            Console.WriteLine($"Subscribe say {e.num} {e.message}");
    }
    public class EventDelegate
    {
       public static void Test()
        {
            Subscriber sb = new Subscriber();
            Publisher pb=new Publisher();
            pb.CustomEvents += new CustomDelegate(sb.HandleNotifiy);
            pb.CustomEvents += delegate (object sender, CustomEventArgs e)
             {
                 Console.WriteLine($"Anomyonous say {e.message} {e.num}");
             };
            pb.CustomEvents += (s, e) => Console.WriteLine($"Lamda say {e.message} {e.num}");
            pb.RaiseNotification();
        }
    }
}
