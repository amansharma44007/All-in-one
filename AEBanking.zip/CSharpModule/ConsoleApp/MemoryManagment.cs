﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class MemoryManagment
    {
        private readonly int Counter;
        private  string[] Name;
        const int max = 10_000;
        public MemoryManagment(int ii)
        {
            Counter = ii;
            Name= new string[max];
            for (int i = 0; i < max; i++)
            {
                Name[i] = $"Some long String to fill memory,{i}";
            }
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"Object {Counter} created");
            Console.ResetColor();
        }
        ~MemoryManagment()
        {
            Name = null;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Object {Counter} Destroyed");
            Console.ResetColor();
        }
        public static void Test()
        {
            string msgFormat = "{0} {1} collection attempt,Generation {2}";
            MemoryManagment mm;
            for (int i = 0; i < 100; i++)
            {
                mm = new MemoryManagment(i);
                if(i>30 && i < 70)
                {
                    Console.WriteLine(msgFormat,"Before","1st",GC.GetGeneration(mm));
                    GC.Collect();
                    Console.WriteLine(msgFormat, "After", "1st", GC.GetGeneration(mm));
                    if(i>50 && i < 61)
                    {
                        GC.Collect();
                        Console.ForegroundColor=ConsoleColor.DarkCyan;
                        Console.WriteLine(msgFormat, "After", "2nd", GC.GetGeneration(mm));
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
            Console.WriteLine("=================");
            Console.WriteLine("Press a key to terminate");
            Console.ReadKey();
        }
    }
}
