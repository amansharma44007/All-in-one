﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Statics
    {
        public static int staticField;
        public int instanceField;

        static Statics() => Console.WriteLine("hello");
        public Statics() => Console.WriteLine("hii");
        public static void StaticMethod()
        {
            staticField = 1;
            Console.WriteLine($"Static Field:{staticField}");
        }
        public void InstanceMethod()
        {
            staticField = 12;
            instanceField = 11;
            Console.WriteLine($"Static Field:{staticField}, Instance Field{instanceField}");
        }
    }
    public class StaticExample
    {
        public static void test()
        {
            Statics sc = new Statics();
            Statics.StaticMethod();
            sc.InstanceMethod();
        }
        
    }
}
