﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    //step 1 declaration
    public delegate int  DelegateInt(int a, int b);
    internal class Delegate1
    {
        public int Add(int x, int y) => x + y;
        static int Minus(int x, int y) => x - y;
        public int Multiply(int x, int y) => x * y;
        static int Divide(int x, int y) => y>0?x/y:0;
        public static void Test()
        {
            Delegate1 d1 = new Delegate1();
            DelegateInt d2= new DelegateInt(d1.Add);
            var result = d2(22, 33);
            Console.WriteLine(result);
            var result1 = d2.Invoke(22, 33);
            Console.WriteLine(result1);
            d2 += new DelegateInt(Minus);
            d2 += new DelegateInt(d1.Multiply);
            d2 += new DelegateInt(Divide);
            
            var r=d2.Invoke(5555, 55);
            Console.WriteLine(r);
            InvokeDelegate(d2);

        }
        static void InvokeDelegate(DelegateInt ad)
        {
            foreach (Delegate item in ad.GetInvocationList())
            {
                var result = item.DynamicInvoke(1000, 5);
                Console.WriteLine(item.Method.Name+" "+result);
            }
        }
    }
}
