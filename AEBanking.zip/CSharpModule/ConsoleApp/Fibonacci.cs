﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Fibonacci
    {
        internal static void Test()
        {
            int n,n1=0,n2=1,n3;
            Console.Write("Enter the value of n (Max-40 and min-1): ");
            n=int.Parse(Console.ReadLine());
            if (n == 1)
            {
                Console.Write(n1);
            }
            if(n == 2)
            {
                Console.Write(n2);
            }
            if (n > 2 && n<41)
            {
                Console.Write(n1 + " " + n2 + " ");
                for (int i = 2; i < n; ++i)
                {
                    n3 = n1 + n2;
                    Console.Write(n3 + " ");
                    n1 = n2;
                    n2 = n3;
                }
            }
            
        }
    }
}
