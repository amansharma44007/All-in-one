﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class BaseClass
    {
        public int publicField;
        private int privateField;
        protected int protectedField;
        internal int internalField;
        protected internal int protectedinternalField;
        public BaseClass()
        {
            Console.WriteLine("Base ctor");
        }
        public BaseClass(int num)
        {
            publicField = privateField = protectedField = internalField = protectedinternalField = num;
        }
        public virtual void show()
        {
            Console.WriteLine("publicField:"+publicField);
            Console.WriteLine("privateField"+privateField);
            Console.WriteLine("proctedField"+protectedField);
            Console.WriteLine("internalField"+internalField);
            Console.WriteLine("protectedinternalField"+protectedinternalField);
        }

    }
    class Derived : BaseClass
    {
        public Derived()
        {
            Console.WriteLine("Derived class ctor");
        }
        public Derived(int num):base(num)
        {
            Console.WriteLine("Derived class int");
        }
        public override void show()
        {
            Console.WriteLine("publicField:" + publicField);
            //Console.WriteLine("privateField" + privateField);
            Console.WriteLine("proctedField" + protectedField);
            Console.WriteLine("internalField" + internalField);
            Console.WriteLine("protectedinternalField" + protectedinternalField);
        }

    }
    abstract class AbstarctClass
    {
        public int field;
        public int FieldSet { get; set; }
        public void show() => Console.WriteLine("FieldSet: "+FieldSet);
        public AbstarctClass() => field = 999;
        public abstract void DoWork();
    }
    class Concrete : AbstarctClass
    {
        public override void DoWork()
        {
            Console.WriteLine("Dowork");
        }
    }
    internal class Inheritance
    {
        public  static void Test()
        {
            BaseClass bc=new BaseClass(22);
            bc.show();
            Derived dc = new Derived(33);
            dc.show();
            bc = dc;
            bc.show();
            AbstarctClass c1 = new Concrete();
            c1.show();
            c1.DoWork();
        }
    }
}
