﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Employee
    {
        #region Fields
        int _eid;
        private string _name;
        #endregion
        #region Properties
        public int EmpId
        {
            get { return _eid; }
            set { _eid = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int Age { get; set; }
        public String Address { get; set; }
        #endregion
        #region constructor
        public Employee(int eid,String name)
        {
            this._eid = eid;
            this._name = name;
        }
        public Employee()
        {
            Console.WriteLine("Constructor");
        }
        #endregion
        #region Method
        public void show()
        {
            Console.WriteLine(_eid+" "+_name+" "+Address+" "+Age);
        }
        #endregion
    }
    internal class Class1
    {
        internal static void Test()
        {
            Employee e1 = new Employee();
            Employee e2 = new Employee(eid: 1, name: "Aman Sharma");
            e1.EmpId = 12;
            e2.EmpId = 22;
            e1.Name = "Stark";
            e2.Name = "Elon";
            e1.Address = "Mumbai";
            e2.Address = "Banglore";
            e1.Age = 22;
            e2.Age = 23;
            e1.show();
            e2.show();
        }
    }
}
