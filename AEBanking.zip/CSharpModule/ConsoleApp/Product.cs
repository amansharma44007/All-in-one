﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Define a class called Product.'
//It should contain fields like _productId:int, _productName: string, _unitsInStock:int, _unitPrice: decimal.
//Define properties for each of the private fields.Write a method called Display() which will display the values of the fields.
namespace ConsoleApp
{
    internal class Product
    {
        #region Properties
        private int _productId { get; set; }
        private String _productName { get; set; }
        private int _unitInStock { get; set; }
        private decimal _unitPrice { get; set; }
        private int _discount { get; set; }
        #endregion
        #region Constructor
        public Product()
        {

        }
        public Product(int productId=0,string productName="null",int unitInStock=0,decimal unitPrice=0)
        {
            this._productId = productId;
            this._unitPrice = unitPrice;
            this._productName = productName;
            this._unitInStock = unitInStock;
        }
        #endregion
        #region Method
        public void Show()
        {
            Console.WriteLine($"ProductId->{_productId},UnitPrice->{_unitPrice},UnitInStock->{_unitInStock},ProductName->{_productName},Discount->{_discount}");
        }
        public void ComputeDiscount()
        {
            if(_unitPrice>10 && _unitInStock > 100)
            {
                _discount = 10;
                
            }
            else
            {
                _discount = 5;
            }
        }
        #endregion
        internal static void Test()
        {
            Product p1 = new Product();
            p1._productName = "Face-Wash";
            p1._unitPrice = 11;
            p1._productId = 2;
            p1._unitInStock = 101;
            p1.ComputeDiscount();
            p1.Show();
            Product p2 = new Product(productId: 1, productName: "Stark Tower", unitInStock: 2, unitPrice: 2);
            p2.ComputeDiscount();
            p2.Show();
        }

    }
    
}
