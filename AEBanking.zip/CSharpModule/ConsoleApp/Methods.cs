﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Methods
    {
        internal static void Test()
        {
            String after = "After", before = "Before", byVal = nameof(SwapByValue), byRef = nameof(SwapByRef);
            String msgFormat = "{0} calling {1},a:{2},b:{3}";
            String Line = "".PadLeft(45, '=');
            Console.Clear();
            int a = 3;
            int b = 4;
            Console.WriteLine(msgFormat,before,byVal,a,b);
            SwapByValue(a, b);
            Console.WriteLine(msgFormat, after, byVal, a, b);
            Console.WriteLine(Line);
            Console.WriteLine(msgFormat, before, byRef, a, b);
            SwapByRef(ref a,ref b);
            Console.WriteLine(msgFormat, after, byRef, a, b);
            Console.WriteLine(Line);
            int num = 2;
            var result = Power(num: num, square: out int sq, cube: out int cu);
            Console.WriteLine($"Number:{num},Square:{sq},Cube{cu},Result{result}");
            Console.WriteLine(Line);
            _=Power(num:num,square: out int sq1, cube: out int cu1);
            _ = Power(num: num, square: out int sq2, cube: out int _);
            Optional(name:"aaa");
            Parmas("22");
            Parmas("1", 1);
            Parmas(req: "3", 1, 2, 3);
            int Add(int a,int b) { return a + b; }
            Console.WriteLine(Add(2,3));
        }
        static void Parmas(String req,params int[] arr)
        {
            Console.WriteLine($"{req}=>{arr.Length}");
        }
        static void Optional(int num=0,String name = "Stark")
        {
            Console.WriteLine(num+" "+name);
        }
        static int Power(int num,out int square,out int cube)
        {
            square = num * num;
            cube = square * num;
            return cube * num;
        }
        static void SwapByValue(int a,int b)
        {
            a = a + b;
            b = a - b;
            a = a - b;
        }
        static void SwapByRef(ref int a,ref int b)
        {
            a = a + b;
            b = a - b;
            a = a - b;
        }
    }
}
