﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public  class CollectionExample
    {
        class GenericCollection<T>
        {
            System.Collections.Generic.List<T> list= new System.Collections.Generic.List<T>();
            public void Add(T emp) => list.Add(emp);
            public void Remove(T emp) => list.Remove(emp);
            public T GetAt(int pos) => (T)list[pos];

        }
        class EmployeeCollection
        {
            ArrayList list = new ArrayList();
            public void Add(Employee emp) => list.Add(emp);
            public void Remove(Employee emp) => list.Remove(emp);
            public Employee GetAt(int pos) => (Employee)list[pos];
            public Employee this[int index]
            {
                get { return GetAt(index <= list.Count ? index : throw new IndexOutOfRangeException()); }
                set { list[index <= list.Count ? index : throw new IndexOutOfRangeException()] = value; }
            }
        }
        
        class IntegerCollection
        {
            ArrayList list = new ArrayList();
            public void Add(int emp) => list.Add(emp);
            public void Remove(int emp) => list.Remove(emp);
            public int GetAt(int pos) => (int)list[pos];
        }
        public static void Test()
        {
            ArrayList list = new ArrayList();
            list.Add(1);
            list.Add("djdb");
            list.Add(true);
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            Hashtable hb=new Hashtable();
            hb.Add(1, "a");
            hb.Add(2, "b"); 
            hb.Add(3, "c");
            if (hb.ContainsKey(4))
            {
                Console.WriteLine("Hastable has 4");
            }
            else
            {
                hb.Add(4, "d");
            }
            foreach (var item in hb.Keys)
            {
                Console.WriteLine($"Key {item} Value {hb[item]}");
            }
            GenericCollection<int> a = new GenericCollection<int>();
            a.Add(22);
            a.Add(222);
            a.Remove(22);
            var aman=a.GetAt(0);
            Console.WriteLine(aman);
            EmployeeCollection ec = new EmployeeCollection();
            Employee e1 = new Employee { EmpId = 3, Address = "fomf", Age = 23, Name = "kjnf" };
            ec.Add(e1);
            var aa = ec[0];
            Console.WriteLine(aa);
        }
    }
}
