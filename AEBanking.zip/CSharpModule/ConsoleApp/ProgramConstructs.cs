﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class ProgramConstructs
    {
        internal static void Test()
        {
            var num = 10;
            if (num > 10)
            {
                Console.WriteLine($"{num}");
            }
            else
            {
                Console.WriteLine("Less than 10");
            }
            Console.WriteLine("Enter the First num: ");
            var num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Second num: ");
            var num2 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2)
            {
                Console.WriteLine("Num1 is greater");
            }
            else
            {
                Console.WriteLine("Num2 is greater");
            }
            
            }
        

    }
}
