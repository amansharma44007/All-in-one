﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class CustomException : System.Exception
    {
        public CustomException() : base() { }
        public CustomException(string message) : base(message) { }
        public CustomException(string message, Exception innerException) : base(message, innerException) { }
        public string FriendlyMessage { get => "There is Some Problem here"; }
    }
    internal class ExceptionalHandling
    {
        static void RaiseException()
        {
            int x = 10, y = 0, z = 0;
            z = x / y;
            Console.WriteLine("Next Line of Code");
        }
        static void HandleException()
        {
            try
            {
                RaiseException();
                Console.WriteLine("Next Line After" + nameof(RaiseException));
            }
            catch(DivideByZeroException dbze)
            {
                Console.WriteLine("DBZE "+dbze.Message+" "+dbze.StackTrace);
            }
            catch (ArithmeticException ae)
            {
                Console.WriteLine("AE " + ae.Message + " " +ae.StackTrace);
            }
            catch (Exception ex)
            {
                Console.WriteLine("EX " + ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                Console.WriteLine("Finally");
            }
            
        }
        static void ThrowCustomException()
        {
            throw new CustomException("Just for time pass");
        }
        internal static void Test()
        {
            HandleException();
            try
            {
                ThrowCustomException();
            }
            catch (CustomException ce)
            {
                Console.WriteLine("Custome Excdption " + ce.FriendlyMessage + " " + ce.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception "+ex.Message);
            }
            
        }
    }
}
