﻿using System;
namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Aman Sharma");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }
            //InputOutput.Test();
            //ProgramConstructs.Test();
            //ArrayExample.Test();
            //Methods.Test();
            //Class1.Test();
            //Fibonacci.Test();
            //GreatestAmongThree.Test();
            //SumOfNaturalNumbers.Test();
            //Product.Test();
            Console.WriteLine("***********");
            //Constructor.Test();
            //Inheritance.Test();
            // MemoryManagment.Test();
            //Interface.Test();
            //StaticExample.test();
            //ExceptionalHandling.Test();
            //CollectionExample.Test();
            // Delegate1.Test();
            //EventDelegate.Test();
            // BuiltInDelegate.Test();
            //Linq.Test();
            //WorkingWithEF1.Test();
            UsingRepository.Test();
        }
    }
}
