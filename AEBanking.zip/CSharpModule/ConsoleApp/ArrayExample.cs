﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class ArrayExample
    {
        internal static void Test()
        {
            int[] arr = new int[100];
            Random rnd = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rnd.Next(minValue: 500, maxValue: 1000);
            }
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Array.Sort(arr);
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Console.Write("Enter the value to search: ");
            var searchFor = int.Parse(Console.ReadLine());
            var foundAt = Array.BinarySearch(array: arr, value: searchFor);
            Console.WriteLine("{0} {1}", searchFor, (foundAt > -1) ? $"{foundAt + 1}" : "Not found");
            int[,] arr1 = new int[5, 5];
            for (int i = 0; i < arr1.GetLength(0); i++)
            {
                for (int j = 0; j < arr1.GetLength(1); j++)
                {
                    arr1[i, j] = rnd.Next(minValue: 500, maxValue: 1000);
                }
            }
            for (int i = 0; i < arr1.GetLength(0); i++)
            {
                for (int j = 0; j < arr1.GetLength(1); j++)
                {
                    Console.Write("{0}\t", arr1[i, j]);
                }
                Console.WriteLine();
            }
            int[,,] arr2 = { { { 1, 2, 3 } }, { { 2, 3, 4 } }, { { 4, 5, 6 } },{ { 3,4,5} } };
            for (int i = 0; i < arr2.GetLength(0); i++)
            {
                for (int j = 0; j < arr2.GetLength(1); j++)
                {
                    for (int k = 0; k < arr2.GetLength(2); k++)
                    {
                        Console.Write("{0}\t",arr2[i,j,k]);
                    }
                    Console.WriteLine();
                }
                int[][] jaggedArray = new int[][]
                {
                    new int[] {1,2,3,4,5},
                    new int[] {1,2,3},
                    arr
                };
                foreach (int [] inner in jaggedArray)
                {
                    foreach (var item in inner)
                    {
                        Console.Write($"{item}\t");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
