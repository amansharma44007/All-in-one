﻿using System;

namespace Assessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Assignment2.Test();
            Definitions.Program.main();
        }
    }
}
