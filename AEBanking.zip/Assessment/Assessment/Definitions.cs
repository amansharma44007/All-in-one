﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    internal class Definitions
    {
        internal class User
        {
            public string name;
            public string email;
            public string Name { get { return name; } set { name = value; } }
            public string Email { get { return email; } set { email = value; } }
            public User(string name,string email)
            {
                this.email = email;
                this.name = name;
            }
            public User()
            {

            }
        } 
        internal class Program
        {
            public static void main()
            {
                string choice="";
                do
                {
                    Console.WriteLine("**********User Managment System************");
                    Console.WriteLine("\t\t1.Name");
                    Console.WriteLine("\t\t2.Email");
                    Console.WriteLine("\t\t3.Exit");
                    Console.Write("Enter your Choice: ");
                    choice=Console.ReadLine();
                    switch (choice)
                    {
                        case "1": GetName(); break;
                        case "2": GetEmail(); break;
                        case "3":   break;
                        
                        default:
                            Console.WriteLine("Wrong choice. Please choose between 1-2 or 3 only.");
                            Console.WriteLine("Press a key to try again.");
                            Console.ReadKey();
                            break;
                    }
                } while (choice != "9");
                
            }
            static void GetName()
            {
                Console.Write("Please Write Name: ");
                try
                {
                    bool a=true;
                    User u1 = new User();
                    u1.Name = Console.ReadLine();
                    if (u1.name.Length < 6)
                    {
                        throw new InvalidNameFormatException("Minimum length should be 6 char:");
                    }
                    if (u1.name.Length > 25)
                    {
                        throw new InvalidNameFormatException("Maximum Length should be of 25 char");
                    }
                    for (int i = 0; i< u1.name.Length; i++)
                    {
                        if (char.IsLetter(u1.name[i]))
                        {
                            continue;
                        }
                        else
                        {
                            a = false;
                            break;
                        }
                    }
                    if (a == false)
                    {
                        throw new InvalidNameFormatException("Not Valid Name!!!!");
                    }
                    else
                    {
                        Console.WriteLine("Valid Name!!!");
                    }
                }
                catch(InvalidNameFormatException ne)
                {
                    Console.WriteLine(ne.Message);
                }
                

                
            }
            static void GetEmail()
            {
                Console.Write("Please Write Email: ");
                try
                {
                    User u1 = new User();
                    u1.email = Console.ReadLine();
                    if (u1.email.Length < 4)
                    {
                        throw new InvalidEmailFormatException("Email is too short!!!");
                    }
                    else if  (u1.email.Length > 50)
                    {
                        throw new InvalidEmailFormatException("Email is too long!!!!");
                    }
                    else if (u1.email.Contains("@"))
                    {
                        Console.WriteLine("Email Valid");
                    }
                    else
                    {
                        throw new InvalidEmailFormatException("InValid Email!!");
                    }
                }
                catch(InvalidEmailFormatException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        internal class InvalidNameFormatException:System.Exception
        {
            public InvalidNameFormatException() : base() { }
            public InvalidNameFormatException(string message) : base(message) { }
            public InvalidNameFormatException(string message, Exception innerException) : base(message, innerException) { }

        }
        internal class InvalidEmailFormatException:System.Exception
        {
            public InvalidEmailFormatException() : base() { }
            public InvalidEmailFormatException(string message) : base(message) { }
            public InvalidEmailFormatException(string message, Exception innerException) : base(message, innerException) { }
        }

    }
}
