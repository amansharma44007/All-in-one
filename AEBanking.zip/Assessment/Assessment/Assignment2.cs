﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    internal  class Assignment2
    {
        public  string InputString { get; set; }
        public string JoinIt(string[] str)
        {
            string a = String.Join("~", str);
            return a;
        }
        public string[] SplitIt(string str)
        {
            var arrayString = str.Split('~');
            return arrayString;
        }
        internal static  void Test()
        {
            Console.WriteLine("Please Enter 3 Words: ");
            string[] str = new string[3];
            for (int i = 0; i < str.Length; i++)
            {
                str[i] = Console.ReadLine();
            }
            Assignment2 a1 = new Assignment2();
            a1.InputString = a1.JoinIt(str);
            Console.WriteLine($"OutPut: {a1.InputString}");
            str = a1.SplitIt(a1.InputString);

        }
    }
}
