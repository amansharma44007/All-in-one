﻿using AEShared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEProcess
{
    internal class Current : Account
    {
        public Current(int id, string name, AccountType type, double amount) : base(id, name, type, amount)
        {

        }
        public override void WithDraw(double amount)
        {
            if (_info.Balance - amount > 4999)
            {
                _info.Balance -= amount;
            }
            else
            {
                Random rnd = new Random();
                var refno = rnd.Next(minValue: 1_00_000, maxValue: 5_00_000);
                var today = DateTime.Now;
                throw new InSufficentFundException
                (accountId: _info.Id, refno: refno, dt: today);
            }
        }
    }
}
