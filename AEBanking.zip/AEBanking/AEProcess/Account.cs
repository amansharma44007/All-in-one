﻿using AEBussinessEntitites;
using AEShared;
using System;

namespace AEProcess
{
    public abstract class Account:IAccount
    {
        protected AccountInfo _info;
        public event TranscationDelegate DepositEvent;
        public event TranscationDelegate WithdrawEvent;
        public Account()
        {

        }
        public Account(int id,string name,AccountType account,double amount)
        {
            _info= new AccountInfo(id,name,account,amount);
        }
        public Account(AccountInfo info)
        {
            _info= info;
        }
        ~Account()
        {
            _info = null;
        }
        public void Deposit(double amount)
        {

            _info.Balance += amount;
            onDepositEvent(amount);
        }
        public abstract void WithDraw(double amount);
        /*{
            if(_info.Type==AccountType.Saving && _info.Balance - amount > 2499)
            {
                _info.Balance -= amount;
            }
            else if (_info.Type == AccountType.Current && _info.Balance - amount > 4999)
            {
                _info.Balance -= amount;
            }
        }*/
        public void FundTransfer(IAccount target,double amount)
        {
            this.WithDraw(amount);
            target.Deposit(amount);
        }
        public override string ToString()
        {
            return _info.ToString();
        }
        protected void onDepositEvent(double amount1)
        {
            var refno = NextRandomNumber();
            TranscationEventArgs e = new TranscationEventArgs
            {
                amount = amount1,
                Refno = refno,
                TranscationDate = DateTime.Now,
                TranscationType = "Deposit"

            };
            DepositEvent?.Invoke(this, e);
        }
        protected void onWithDrawEvent(double amount1)
        {
            var refno = NextRandomNumber();
            TranscationEventArgs e = new TranscationEventArgs
            {
                amount = amount1,
                Refno = refno,
                TranscationDate = DateTime.Now,
                TranscationType = "Withdraw"

            };
            DepositEvent?.Invoke(this, e);
        }
        private int NextRandomNumber()
        {
            var random = new Random(); 
            return random.Next(minValue:1_23_456,maxValue:8_76_344);
        }

    }
}
