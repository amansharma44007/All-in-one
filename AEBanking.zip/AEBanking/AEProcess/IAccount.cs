﻿using AEShared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEProcess
{
    public interface IAccount
    {
        void Deposit(double amount);
        void WithDraw(double amount);
        void FundTransfer(IAccount ac1, double amount);
        string ToString();
        public event TranscationDelegate DepositEvent;
        public event TranscationDelegate WithdrawEvent;
    }
}
