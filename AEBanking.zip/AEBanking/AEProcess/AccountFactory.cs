﻿using AEBussinessEntitites;
using AEDataAccess;
using AEShared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEProcess
{
    public  class AccountFactory
    {
        public static AccountCollection collection = new AccountCollection();
        public static IAccount CreateAccount(int id,string name,AccountType type,double amount)
        {
            IAccount acc = null;
            var obj = collection.FindAccount(name,out int _);
            if(obj == null)
            {
                if (type == AccountType.Saving && amount > 4999)
                {
                    AccountInfo accountInfo = new AccountInfo(id, name, type, amount);
                    acc = new Savings(accountInfo);
                    collection.AddAccount(accountInfo);
                }
                else if (type == AccountType.Current && amount > 9999)
                {
                    acc = new Current(id, name, type, amount);
                    collection.AddAccount(new AccountInfo(id, name, type, amount));
                }
            }
            else
            {
                acc=obj.Type==AccountType.Saving?
                    new Savings(obj):
                    new Current(id,obj.Name,obj.Type,obj.Balance);
            }
            
            return acc;

        }
    }
}
