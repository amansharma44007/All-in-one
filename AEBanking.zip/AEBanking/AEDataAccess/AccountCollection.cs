﻿using AEBussinessEntitites;
using System;
using System.Collections.Generic;
namespace AEDataAccess {

    public class AccountCollection
    {
        //private AccountInfo[] accounts = new AccountInfo[10];
        //using.System.Collection.Generic
        private List<AccountInfo> accounts = new List<AccountInfo>();
        private static int currentCounter = 0;
        public AccountInfo FindAccount(String name, out int index)
        {
            index = -1;
            foreach (var item in accounts)
            {
                index++;
                if (item?.Name.ToLower() == name)
                {
                    return item;
                }
            }
            return null;
        }
        public void AddAccount(AccountInfo acc1)
        {
            var obj = FindAccount(acc1.Name, out int _);
            if (obj is null)
            {
                //accounts[currentCounter++] = acc1;
                accounts.Add(acc1);
            }
        }
        public void RemoveAccount(AccountInfo acc1)
        {
            var obj = FindAccount(acc1.Name, out int index);
            if (obj is null)
            {
                //accounts[index] = null;
                accounts.Remove(acc1);
            }
        }
    }
}
