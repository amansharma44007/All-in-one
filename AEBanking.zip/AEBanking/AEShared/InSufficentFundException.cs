﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEShared
{
    public class InSufficentFundException:Exception
    {
        public int AccountId { get;set; }
        public DateTime TranscationDate { get; set; }
        public int RefNo { get; set; }
        public InSufficentFundException(int accountId,DateTime dt,int refno):base()
        {
            AssignValues(accountId, dt, refno);
        }
        public InSufficentFundException(string message,int accountId, DateTime dt, int refno) : base(message)
        {
            AssignValues(accountId, dt, refno);
        }
        public InSufficentFundException(string message,Exception innerException, int accountId, DateTime dt, int refno) : base(message,innerException)
        {
            AssignValues(accountId, dt, refno);
        }
        private void AssignValues(int accountId,DateTime dt,int refno)
        {
            AccountId = accountId;
            TranscationDate = dt;
            RefNo=refno;
        }
        public string CustomMessage
        {
            get{ 
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("A transcation {0}", RefNo)
                    .AppendFormat("For account {0}", AccountId)
                    .AppendFormat(" {0}-{1} ", TranscationDate.ToShortDateString(), TranscationDate.ToShortTimeString())
                    .AppendFormat("Has failed due to insuffiecent amount");
                return sb.ToString();
            }
        }

    }
}
