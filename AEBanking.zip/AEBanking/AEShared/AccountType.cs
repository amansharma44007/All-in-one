﻿using System;

namespace AEShared
{
    public enum AccountType
    {
        None,Saving,Current
    }
}
