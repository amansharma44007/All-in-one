﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEShared
{
    public class TranscationEventArgs : EventArgs
    {
        public DateTime TranscationDate { get; set; }
        public int Refno { get; set; }
        public double amount { get; set; }
        public string TranscationType { get; set; }
        public override string ToString()
        {
            return $"Amount {amount:C} was {(TranscationType.StartsWith("D") ? "Deposited" : "Withdraw")} " +
                $"{(TranscationType.StartsWith("D") ? "into" : "from")} your account on"
                + $"{TranscationDate.ToShortDateString()}-{TranscationDate.ToShortDateString()}" +
                $"With reference no {Refno}";
        }
    }
    public delegate void  TranscationDelegate(object sender, TranscationEventArgs args);
}
