﻿using AEProcess;
using AEShared;
using System;
using AEProcess;

namespace AEBankingApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            IAccount acc = AccountFactory.CreateAccount(1, "Aman", AccountType.Saving, 5000);
            acc.DepositEvent += (s, e) => Console.WriteLine(e);
            acc.WithdrawEvent+=(s, e) => Console.WriteLine(e);
            Console.WriteLine(acc);
            acc.Deposit(1000);
            Console.WriteLine(acc);
            try
            {
                acc.WithDraw(4000);
            }
            catch (InSufficentFundException ise)
            {
                Console.WriteLine(ise.CustomMessage);
            }
            
            Console.WriteLine(acc);
            IAccount acc1 = AccountFactory.CreateAccount(2, "Elon", AccountType.Saving, 55000);
            Console.WriteLine(acc1);
            acc1.Deposit(1000);
            Console.WriteLine(acc1);
            acc1.WithDraw(1000);
            Console.WriteLine(acc1);
            acc1.FundTransfer(acc,1000);
            Console.WriteLine(acc1);
            Console.WriteLine(acc);
        }
    }
}
