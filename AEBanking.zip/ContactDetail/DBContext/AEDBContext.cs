﻿using ContactEntities;
using Microsoft.EntityFrameworkCore;
using System;

namespace DBContext
{
    public class AEDBContext : Microsoft.EntityFrameworkCore.DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                connectionString: @"server=(localdb)\MSSQLLocalDB;database=AEDB;integrated security=sspi;MultipleActiveResultSets=true"
        );
        }
        public DbSet<ContactInfo> Contacts { get; set; }
    }
}
