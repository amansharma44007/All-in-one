﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ContactEntities
{
    public class ContactInfo
    {
        [Key]
        public int ContactId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string MobileNumber { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City {get; set; }
        public string PostalCode { get; set; }
        public DateTime BirthDate { get; set; }
        public char Gender { get; set; }
    }
}
