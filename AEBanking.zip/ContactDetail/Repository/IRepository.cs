﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public  interface IRepository<TEntity,TIdentity>
    {
            IEnumerable<TEntity> GetAll();
            IEnumerable<TEntity> GetByCity(string p);
            IEnumerable<TEntity> GetByGender(char p);
            TEntity GetById(TIdentity id);
            IEnumerable<TEntity> GetByEmailId(string p);
            void Insert(TEntity item);
            void Update(TEntity item);
            void Delete(TIdentity id);
            void DeleteByCity(TIdentity id);

    }
}
