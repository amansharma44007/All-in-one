﻿using ContactEntities;
using DBContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Repository
{
    public class Repository : IRepository<ContactInfo, string>
    {
        AEDBContext db;
        public Repository()
        {
            db = new AEDBContext();
        }
        public IEnumerable<ContactInfo> GetAll()
        {
            return db.Contacts.AsNoTracking().ToList();
        }
        
        public IEnumerable<ContactInfo> GetByCity(string p)
        {
            return db.Contacts.AsNoTracking().AsEnumerable().Where(c => c.City.ToLower() == p.ToLower()).ToList();
        }

        public IEnumerable<ContactInfo> GetByGender(char p)
        {
            return db.Contacts.AsNoTracking().AsEnumerable().Where(c => c.Gender == p).ToList();
        }
        public IEnumerable<ContactInfo> GetByEmailId(string p)
        {
            return db.Contacts.AsNoTracking().AsEnumerable().Where(c => c.EmailId.ToLower() == p.ToLower()).ToList();
        }

        public void Insert(ContactInfo item)
        {
            db.Add(item);
            db.SaveChanges();
        }

        public ContactInfo GetById(string id)
        {
            int id1 = int.Parse(id);
            return db.Contacts.AsNoTracking().FirstOrDefault(c => c.ContactId == id1);
        }

        public void Update(ContactInfo item)
        {
            db.Update(item);
            db.SaveChanges();
        }

        public void Delete(string id)
        {
            int id1 = int.Parse(id);
            var obj = db.Contacts.AsNoTracking().FirstOrDefault(c => c.ContactId == id1);
            if (obj != null)
            {
                db.Contacts.Remove(obj);
                db.SaveChanges();
            }
        }
        public void DeleteByCity(string id)
        {
            var item = GetByCity(id);
            db.Contacts.RemoveRange(item);
            db.SaveChanges();
            
        }
    }
}
