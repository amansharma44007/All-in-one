﻿using ContactEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class UsingRepository
    {
        public static void Test()
        {
            new UsingRepository().Run();
        }
        IRepository<ContactInfo, string> repository;
        public UsingRepository()
        {
            repository = new Repository();
        }
        public void Run()
        {
            string choice = "";
            do
            {
                BuildMenu();
                SwitchChoices();
            } while (choice != "9");
            void SwitchChoices()
            {
                switch (choice)
                {
                    case "1": GetAllCustomers(); break;
                    case "2": GetByCity(); break;
                    case "3": GetByGender(); break;
                    case "4": GetByEmailId(); break;
                    case "5": InsertNewCustomer(); break;
                    case "6": UpdateCustomer(); break;
                    case "7": DeleteCustomer(); break;
                    case "8":DeleteCustomerByCity();break;
                    case "9":break;
                    default:
                        Console.WriteLine("Wrong choice. Please choose between 1-6 or 9 only.");
                        Console.WriteLine("Press a key to try again.");
                        Console.ReadKey();
                        break;
                }
            }
            void BuildMenu()
            {
                Console.Clear();
                Console.WriteLine("*****************  Customer management ******************");
                Console.WriteLine("\t\t1. Show All Customers");
                Console.WriteLine("\t\t2. Get Customers By City");
                Console.WriteLine("\t\t3. Get Customers By Gender");
                Console.WriteLine("\t\t4. Get Customers By EmailId");
                Console.WriteLine("\t\t5. Insert Customer Data");
                Console.WriteLine("\t\t6. Update Customer Data");
                Console.WriteLine("\t\t7. Remove Customer");
                Console.WriteLine("\t\t8. Remove Customer By City: ");
                Console.WriteLine("\n\t\t9. Quit");
                Console.Write("\nEnter Choice (1-8 OR 9 to exit): ");
                choice = Console.ReadLine();
            }
        }
        private void ClearScreenHelper()
        {
            Console.WriteLine("\n\n Press a key to go back to menu");
            Console.ReadKey();
        }
        private void GetAllCustomers()
        {
            Console.Clear();
            Console.WriteLine("************List of Customer**************");
            var items = repository.GetAll();
            items.ToList().ForEach(c => Console.WriteLine($"{(c.Gender == 'M' ? "Mr." : "Ms.")} {c.FirstName} {c.LastName} {c.MobileNumber}")
            );
            ClearScreenHelper();
        }
        private void GetByCity()
        {
            Console.Clear();
            Console.WriteLine("************List of Customer By Filter**************");
            Console.Write("Please Enter The City to search in Customers: ");
            string p = Console.ReadLine();
            var items = repository.GetByCity(p);
            items.ToList().ForEach(c => Console.WriteLine($"{(c.Gender == 'M' ? "Mr." : "Ms.")} {c.FirstName} {c.LastName} {c.MobileNumber}")
            );
            ClearScreenHelper();
        }
        private void GetByGender()
        {
            Console.Clear();
            Console.WriteLine("************List of Customer By Filter**************");
            Console.Write("Please Enter The Gender to search in Customers(M/F): ");
            char p = Console.ReadLine()[0];
            var items = repository.GetByGender(p);
            items.ToList().ForEach(c => Console.WriteLine($"{(c.Gender == 'M' ? "Mr." : "Ms.")} {c.FirstName} {c.LastName} {c.MobileNumber}")
            );
            ClearScreenHelper();
        }
        private void GetByEmailId()
        {
            Console.Clear();
            Console.WriteLine("************List of Customer By Filter**************");
            Console.Write("Please Enter The Email to search in Customers: ");
            string p = Console.ReadLine();
            var items = repository.GetByEmailId(p);
            items.ToList().ForEach(c => Console.WriteLine($"{(c.Gender == 'M' ? "Mr." : "Ms.")} {c.FirstName} {c.LastName} {c.MobileNumber}")
            );
            ClearScreenHelper();
        }
        private void InsertNewCustomer()
        {
            Console.WriteLine("*****************Insert****************");
            ContactInfo c = new ContactInfo();
            Console.Write("Enter the First Name: ");
            c.FirstName = Console.ReadLine().ToLower();
            Console.Write("Enter the LastName Name: ");
            c.LastName = Console.ReadLine().ToLower();
            Console.Write("Enter the EmailId: ");
            c.EmailId = Console.ReadLine().ToLower();
            Console.Write("Enter the City: ");
            c.City = Console.ReadLine().ToLower();
            Console.Write("Enter the MobileNumber: ");
            c.MobileNumber = Console.ReadLine();
            Console.Write("Enter the Address1: ");
            c.AddressLine1 = Console.ReadLine().ToLower();
            Console.Write("Enter the Address2: ");
            c.AddressLine2 = Console.ReadLine().ToLower();
            Console.Write("Enter the PostalCode: ");
            c.PostalCode = Console.ReadLine().ToLower();
            Console.Write("Enter the BirthDate(dd-mm-yyyy): ");
            DateTime d;
            var aman = Console.ReadLine();
            bool chValidity = DateTime.TryParseExact(
         aman,
         "dd-MM-yyyy",
         CultureInfo.InvariantCulture,
         DateTimeStyles.None,
         out d);
            if (chValidity)
            {
                c.BirthDate = d;
            }
            else
            {
                c.BirthDate = default(DateTime);
            }
            Console.Write("Enter the Gender: ");
            var a = Convert.ToChar(Console.ReadLine().ToUpper());
            if (a == 'M' || a == 'F')
            {
                c.Gender = a;
            }
            else
            {
                c.Gender = 'z';
            }
            if (c.Gender == 'z' || string.IsNullOrEmpty(c.FirstName) || string.IsNullOrEmpty(c.LastName)
                || string.IsNullOrEmpty(c.EmailId) || string.IsNullOrEmpty(c.City) || string.IsNullOrEmpty(c.MobileNumber) || string.IsNullOrEmpty(c.AddressLine1)
                || string.IsNullOrEmpty(c.AddressLine2) || string.IsNullOrEmpty(c.PostalCode) || c.BirthDate == default(DateTime)
                )
            {
                Console.WriteLine(c.Gender == 'z');
                Console.WriteLine(c.Gender);
                Console.WriteLine("1 or more field is empty or null");
                ClearScreenHelper();
                return;
            }
            else
            {
                repository.Insert(c);
            }
            ClearScreenHelper();

        }
        private void UpdateCustomer()
        {
            Console.WriteLine("*****************Update****************");
            Console.Write("Please Enter the Id: ");
            var c = Console.ReadLine();
            var c1 = repository.GetById(c);
            if (c1 is null)
            {
                Console.WriteLine("There is no Id like that is there in database!!");
                ClearScreenHelper();
            }
            else
            {
                Console.WriteLine($"The current value of Firstname:{c1.FirstName} ");
                Console.Write("Enter the First Name: ");
                string a = Console.ReadLine();
                c1.FirstName = string.IsNullOrEmpty(a) ? c1.FirstName : a;
                Console.WriteLine($"The current value of LastName:{c1.LastName} ");
                Console.Write("Enter the LastName Name: ");
                a = Console.ReadLine();
                c1.LastName = string.IsNullOrEmpty(a) ? c1.LastName : a;
                Console.WriteLine($"The current value of EmailId:{c1.EmailId} ");
                Console.Write("Enter the EmailId: ");
                a = Console.ReadLine();
                c1.EmailId = string.IsNullOrEmpty(a) ? c1.EmailId : a;
                Console.WriteLine($"The current value of City:{c1.City} ");
                Console.Write("Enter the City: ");
                a = Console.ReadLine();
                c1.City = string.IsNullOrEmpty(a) ? c1.City : a;
                Console.WriteLine($"The current value of MobileNumber:{c1.MobileNumber} ");
                Console.Write("Enter the MobileNumber: ");
                a = Console.ReadLine();
                c1.MobileNumber = string.IsNullOrEmpty(a) ? c1.MobileNumber : a;
                Console.WriteLine($"The current value of Address1:{c1.AddressLine1} ");
                Console.Write("Enter the Address1: ");
                a = Console.ReadLine();
                c1.AddressLine1 = string.IsNullOrEmpty(a) ? c1.AddressLine1 : a;
                Console.WriteLine($"The current value of Address2:{c1.AddressLine2} ");
                Console.Write("Enter the Address2: ");
                a = Console.ReadLine();
                c1.AddressLine2 = string.IsNullOrEmpty(a) ? c1.AddressLine2 : a;
                Console.WriteLine($"The current value of PostalCode:{c1.PostalCode} ");
                Console.Write("Enter the PostalCode: ");
                a = Console.ReadLine();
                c1.PostalCode = string.IsNullOrEmpty(a) ? c1.PostalCode : a;

                Console.WriteLine($"The Current value of BirthDate :{c1.BirthDate}");
                Console.Write("Enter the BirthDate(dd-mm-yyyy): ");
                DateTime d;
                var aman = Console.ReadLine();
                bool chValidity = DateTime.TryParseExact(
             aman,
             "dd-MM-yyyy",
             CultureInfo.InvariantCulture,
             DateTimeStyles.None,
             out d);
                if (chValidity)
                {
                    c1.BirthDate = d;
                }


                Console.WriteLine($"The Current value of Gender: {c1.Gender}");
                Console.Write("Enter the Gender: ");
                var a1 = Convert.ToChar(Console.ReadLine().ToUpper());
                if (a1 == 'M' || a1 == 'F')
                {
                    c1.Gender = a1;
                }
                repository.Update(c1);
                ClearScreenHelper();
            }
            

        }

        private void DeleteCustomer()
        {
            Console.WriteLine("***********Delete**************");
            Console.Write("Please Enter the Id: ");
            var c = Console.ReadLine();
            var c1 = repository.GetById(c);
            if (c1 is null)
            {
                Console.WriteLine("No there is no Id here");
            }
            else
            {
                Console.WriteLine($"{(c1.Gender == 'M' ? "Mr." : "Ms.")} {c1.FirstName} {c1.LastName}");
                Console.Write("Are you want to delete");
                var a = Console.ReadLine().ToLower();
                if (a == "y")
                {
                    repository.Delete(c);
                }
            }
            ClearScreenHelper();
        }
        private void DeleteCustomerByCity()
        {
            Console.WriteLine("***********Delete by city**************");
            Console.Write("Please Enter the city: ");
            var c = Console.ReadLine();
            var c1 = repository.GetByCity(c);
            if (c1 is null)
            {
                Console.WriteLine("No there is no City here");
            }
            else
            {
                Console.Write($"Are you want to delete All people from {c}: ");
                foreach (var item in c1)
                {
                    Console.WriteLine($"{(item.Gender == 'M' ? "Mr." : "Ms.")} {item.FirstName} {item.LastName} ");
                }
                var a = Console.ReadLine().ToLower();
                if (a == "y")
                {
                    repository.DeleteByCity(c);
                }
            }
            ClearScreenHelper();
        }
    }
}
