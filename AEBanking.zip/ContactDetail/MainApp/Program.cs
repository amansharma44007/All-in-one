﻿using Repository;
using System;

namespace MainApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            UsingRepository.Test();
        }
    }
}
