﻿using ContactDataAcess;
using ContactEntities;
using System;
using System.Collections.Generic;

namespace ContactManagementProcess
{
    
    public class Contact 
    {
        static ContactCollections contacts = new ContactCollections();
        public static  void  CreateContact(string name,int phone,string email)
        {
            ContactInfo c1 = new ContactInfo(0,phone,email,name);
            contacts.AddAccount(c1);

        }

        static public List<ContactInfo> SearchByGmail(string email)
        {
            var answer = contacts.SearchByGmail(email);
            if ( answer!= null)
            {
                return answer;
            }
            return null;
        }

        static public ContactInfo SearchByPhone(int num)
        {
            var answer=contacts.SearchByPhoneNo(num);
            if (answer != null)
            {
                return answer;
            }
            return null;
        }
    }
}
