﻿using ContactManagementProcess;
using System;

namespace ContactApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            int choice;
            bool a = true;
            void Continue()
            {
                Console.Write("Do you want to continue:(Y/N) ");
                string v = Console.ReadLine().ToLower();
                if (v == "n")
                {
                    Console.WriteLine("Thank You");
                    a = false;
                }
            }
            while (a)
            {
                Console.WriteLine("************************WELCOME TO CONTACT MANAGER***********************");
                Console.WriteLine("1.Create new Contact");
                Console.WriteLine("2.Get Phone Number");
                Console.WriteLine("3.Get Email Address");
                Console.WriteLine("4.Quit");
                Console.Write("Enter Your Choice: ");
                choice=int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.Write("Please Enter your Name: ");
                        var name = Console.ReadLine();
                        Console.Write("Please Enter Your Contact No: ");
                        var phoneNo = int.Parse(Console.ReadLine());
                        Console.Write("Please Enter Your email: ");
                        var email = Console.ReadLine().ToLower();
                        Contact.CreateContact(name, phoneNo, email);
                        Console.WriteLine();
                        Continue();
                        


                        break;
                    case 2:
                        Console.Write("Please Enter the Phone Number: ");
                        var num = int.Parse(Console.ReadLine());
                        var answer=Contact.SearchByPhone(num);
                       
                        if (answer != null)
                        {
                            Console.WriteLine("Contact has been Found");
                            Console.WriteLine($"Name: {answer.Name}");
                            Console.WriteLine($"Email: {answer.Email}");
                            Console.WriteLine($"PhoneNo: {answer.PhoneNo}");
                            Console.WriteLine();
                        }
                        
                        else
                        {
                            Console.WriteLine("Sorry Contact Not there");
                            Console.WriteLine();
                        }
                        Continue();
                        break;
                    case 3:
                        Console.Write("Please Enter the Gmail: ");
                        var findEmail = Console.ReadLine().ToLower();
                        var ans = Contact.SearchByGmail(findEmail);
                        if(ans != null)
                        {
                            Console.WriteLine("Contact has been Found");
                            Console.WriteLine();
                            foreach (var item in ans)
                            {
                                
                                Console.WriteLine($"Name: {item.Name}");
                                Console.WriteLine($"Email: {item.Email}");
                                Console.WriteLine($"PhoneNo: {item.PhoneNo}");
                                Console.WriteLine();
                            }
                        }
                        else
                        {
                            Console.WriteLine("Sorry Gmail Not there!!!");
                            Console.WriteLine();
                        }
                        Continue();
                        break;
                    case 4:
                        Console.WriteLine("Thank You for Using Contact App");
                        a=false;
                        break;
                    default:
                        Console.WriteLine("You have Typed Wrong Input!!!");
                        break;
                }
                


            }
        }
        
    }
}
