﻿using System;

namespace ContactEntities
{
    public class ContactInfo
    {
        #region Fields
        public int _id;
        public int _phoneNo;
        public string _email;
        public string _name;
        #endregion

        #region Properties
        public int Id { get { return _id; } set { _id = value; } }
        public int PhoneNo { get { return _phoneNo; } set { _phoneNo = value; } }
        public string Email { get { return _email; } set { _email = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        #endregion
        #region Constructor
        public ContactInfo()
        {

        }
        public ContactInfo(int id,int phoneNo,string email,string name)
        {
            _id = id;
            _email = email;
            _phoneNo=phoneNo;
            _name = name; 
        }
        #endregion
        #region Overrides
        public override string ToString()
        {
            return $"Id: {_id} ,Name: {_name},PhoneNo: {_phoneNo},Email: {_email}";
        }
        #endregion
    }
}
