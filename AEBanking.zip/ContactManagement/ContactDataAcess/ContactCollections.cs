﻿using System;
using System.Collections.Generic;
using ContactEntities;

namespace ContactDataAcess
{
    public class ContactCollections
    {
        private List<ContactInfo> contacts = new List<ContactInfo>();
        private static int currentCounter = 1;
        public ContactInfo FindAccount(String name)
        {
            foreach (var item in contacts)
            {
                if (item?.Name.ToLower() == name)
                {
                    return item;
                }
            }
            return null;
        }
        public void AddAccount(ContactInfo acc1)
        {
            acc1.Id = currentCounter++;
            var obj = SearchByPhoneNo(acc1.PhoneNo);
            if (obj is null)
            {
                contacts.Add(acc1);
            }
            else
            {
                Console.WriteLine("This Phone No is Already there!!");
                currentCounter--;
            }
        }
        public List<ContactInfo> SearchByGmail(string email)
        {
            List<ContactInfo> con=new List<ContactInfo>();
            foreach (var item in contacts)
            {
                if (item?.Email.ToLower() == email)
                {
                    con.Add(item);
                }
            }
            if(con.Count > 0)
            {
                return con;
            }
            return null;
        }
        public ContactInfo SearchByPhoneNo(int num)
        {
            foreach (var item in contacts)
            {
                if (item?._phoneNo == num)
                {
                    return item;
                }
                
            }
            return null;
        }
    }
}
